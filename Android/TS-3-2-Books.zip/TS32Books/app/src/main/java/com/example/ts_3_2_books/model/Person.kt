package com.example.ts_3_2_books.model

class Person() {
    var name: String = ""
    var sex: String = ""
    var age: Int = 0
    override fun toString(): String {
        return "Person(name='$name', sex='$sex', age=$age)"
    }


}