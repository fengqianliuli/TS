package com.example.ts_3_2_books

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import com.example.ts_3_2_books.model.Book
import com.example.ts_3_2_books.model.Person
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    private var books = ArrayList<Book>()
    private var booksResult = ArrayList<Book>()
    private var person = Person()
    var isHistory = false
    var isSuspense = false
    var isLiterature = false
    var age = 0
    var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initData()
        setListener()

    }

    fun setListener() {
        sexRadioGroup.setOnCheckedChangeListener { group, checkedId ->
            when(checkedId) {
                R.id.maleRadio -> person.sex = "男"
                R.id.femaleRadio -> person.sex = "女"
            }
        }
        historyCheckBox.setOnCheckedChangeListener { buttonView, isChecked ->
            isHistory = isChecked
        }
        suspenseCheckBox.setOnCheckedChangeListener { buttonView, isChecked ->
            isSuspense = isChecked
        }
        literatureCheckBox.setOnCheckedChangeListener { buttonView, isChecked ->
            isLiterature = isChecked
        }
        seekBar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seek: SeekBar,
                                           progress: Int, fromUser: Boolean) {
                // write custom code for progress is changed
            }

            override fun onStartTrackingTouch(seek: SeekBar) {
                // write custom code for progress is started
            }

            override fun onStopTrackingTouch(seek: SeekBar) {
                // write custom code for progress is stopped
                age = seek.progress
                ageTextView.text = age.toString()
                person.age = age
            }
        })
        findBtn.setOnClickListener {
            val lendingTimeStr = lendingTimeEdt.text.toString()
            val returnTimeStr = returnTime.text.toString()
            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd")
            var lendingTime: Date? = null
            try {
                lendingTime = simpleDateFormat.parse(lendingTimeStr)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "时间格式出现错误，请重新输入", Toast.LENGTH_SHORT).show()
            }
            val returnTime = simpleDateFormat.parse(returnTimeStr)
            lendingTime?.let { if (lendingTime.after(returnTime)) {
                finish()
                Toast.makeText(this, "借出时间在归还时间之后，程序结束", Toast.LENGTH_SHORT).show()
            } else {
                search()
            } }
        }
        nextBtn.setOnClickListener {
            currentIndex ++
            if (currentIndex < booksResult.size) {
                bookImage.setImageResource(booksResult[currentIndex].pic)
                bookName.text = booksResult[currentIndex].name
                val sb = StringBuilder()
                if (booksResult[currentIndex].history) {
                    sb.append("历史 ")
                }
                if (booksResult[currentIndex].suspense) {
                    sb.append("悬疑 ")
                }
                if (booksResult[currentIndex].literature) {
                    sb.append("文艺 ")
                }
                bookType.text = sb.toString()
                bookApplicableAge.text = booksResult[currentIndex].applicableAge.toString()
            } else {
                Toast.makeText(this, "已经没有啦！", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun search() {
        booksResult.clear()
        currentIndex = 0
        for (book in books) {
            if (book.applicableAge <= age &&
                (book.history == isHistory || book.suspense == isSuspense || book.literature == isLiterature)) {
                booksResult.add(book)
            }
        }
        if (currentIndex < booksResult.size) {
            bookImage.setImageResource(booksResult[currentIndex].pic)
            bookName.text = booksResult[currentIndex].name
            val sb = StringBuilder()
            when{
                booksResult[currentIndex].history -> sb.append("历史 ")
                booksResult[currentIndex].suspense -> sb.append("悬疑 ")
                booksResult[currentIndex].literature -> sb.append("文艺 ")
            }
            bookType.text = sb.toString()
            bookApplicableAge.text = booksResult[currentIndex].applicableAge.toString()
        }

        person.name = readersNameEdt.text.toString()
        Toast.makeText(this, person.toString(), Toast.LENGTH_SHORT).show()
    }

    fun initData() {
        // 数据初始化
        books.add(Book("人生感悟", false, false,true, 40, R.drawable.aa))
        books.add(Book("边城", true, false, true, 18, R.drawable.bb))
        books.add(Book("sapir", false, false, false, 20, R.drawable.cc))
        books.add(Book("光辉岁月", true, false, true, 25, R.drawable.dd))
        books.add(Book("宋词三百首", true, false, true, 8, R.drawable.ee))
        books.add(Book("中国古代文学教学纲要", true, false, true, 23, R.drawable.ff))
        books.add(Book("无花果", false,false, true, 25, R.drawable.gg))
        books.add(Book("古镇记忆", true, false,false, 24, R.drawable.hh))
    }
}