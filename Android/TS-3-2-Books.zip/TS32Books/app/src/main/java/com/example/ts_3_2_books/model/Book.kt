package com.example.ts_3_2_books.model

class Book (val name: String, val history: Boolean, val suspense: Boolean, val literature: Boolean, val applicableAge: Int, val pic: Int){

}